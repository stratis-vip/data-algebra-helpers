module Main (main) where

import Data.Algebra.Helpers (runTests)

main :: IO ()
main = runTests
